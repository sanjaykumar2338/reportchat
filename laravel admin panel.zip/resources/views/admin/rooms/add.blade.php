@extends('layouts.admin')

@section('content')

@include('layouts.sidebar')

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2>{{ isset($room) ? 'Editar Sala' : 'Agregar Sala' }}</h2>
        <a href="{{ route('admin.rooms.index') }}" class="btn btn-secondary">Volver</a>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger" style="margin-left: 176px; width: 92%;">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ isset($room) ? route('admin.rooms.update', $room->id) : route('admin.rooms.store') }}" method="POST" enctype="multipart/form-data" style="margin-left: 176px; width: 92%;">
        @csrf
        @if(isset($room))
            @method('PUT')
        @endif

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $room->name ?? '') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Piso</label>
            <input type="text" name="floor" class="form-control" value="{{ old('floor', $room->floor ?? '') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <select name="category" class="form-control" required>
                <option value="">Seleccionar Categoría</option>
                <option value="Sala" {{ old('category', $room->category ?? '') == 'Sala' ? 'selected' : '' }}>Sala</option>
                <option value="Auditorio" {{ old('category', $room->category ?? '') == 'Auditorio' ? 'selected' : '' }}>Auditorio</option>
                <option value="Roof" {{ old('category', $room->category ?? '') == 'Roof' ? 'selected' : '' }}>Roof</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="company">Empresa</label>
            <select name="company" id="company" class="form-control">
                <option value="">Seleccionar una empresa</option>
                @foreach($companies as $company)
                    <option value="{{ $company->id }}"
                        {{ old('company', isset($room) ? $room->company : '') == $company->id ? 'selected' : '' }}>
                        {{ $company->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3 row">
            <div class="col">
                <label class="form-label">Disponible Desde</label>
                <input type="time" name="available_from" class="form-control" value="{{ old('available_from', $room->available_from ?? '') }}" required>
            </div>
            <div class="col">
                <label class="form-label">Disponible Hasta</label>
                <input type="time" name="available_to" class="form-control" value="{{ old('available_to', $room->available_to ?? '') }}" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Capacidad</label>
            <input type="number" name="capacity" class="form-control" value="{{ old('capacity', $room->capacity ?? '') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Imagen</label>
            <input type="file" name="image" class="form-control">
            @if(isset($room) && $room->image_url)
                <div class="mt-2">
                    <img src="{{ url($room->image_url) }}" alt="Imagen de la Sala" width="120">
                    <div class="form-check mt-2">
                        <input type="checkbox" name="remove_image" class="form-check-input" id="remove_image">
                        <label class="form-check-label" for="remove_image">Eliminar imagen existente</label>
                    </div>
                </div>
            @endif
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary">{{ isset($room) ? 'Actualizar Sala' : 'Crear Sala' }}</button>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const timeInputs = document.querySelectorAll('input[type="time"]');
        const fromInput = document.querySelector('input[name="available_from"]');
        const toInput = document.querySelector('input[name="available_to"]');
        const form = document.querySelector('form');

        function roundTime(input) {
            if (!input.value) return;
            let [hour, minute] = input.value.split(':');
            minute = parseInt(minute);
            if (minute !== 0 && minute !== 30) {
                let rounded = minute < 30 ? '00' : '30';
                input.value = `${hour.padStart(2, '0')}:${rounded}`;
            }
        }

        function isValidTimeRange() {
            if (fromInput.value && toInput.value) {
                const [fromHour, fromMin] = fromInput.value.split(':').map(Number);
                const [toHour, toMin] = toInput.value.split(':').map(Number);

                const fromMinutes = fromHour * 60 + fromMin;
                const toMinutes = toHour * 60 + toMin;

                return toMinutes > fromMinutes;
            }
            return true;
        }

        function validateTimeOrder() {
            if (!isValidTimeRange()) {
                alert('La hora de finalización debe ser después de la hora de inicio.');
                toInput.value = '';
            }
        }

        roundTime(fromInput);
        roundTime(toInput);

        timeInputs.forEach(input => {
            input.addEventListener('change', function () {
                roundTime(this);
                validateTimeOrder();
            });
            input.addEventListener('keydown', e => e.preventDefault());
        });

        form.addEventListener('submit', function (e) {
            roundTime(fromInput);
            roundTime(toInput);
            if (!isValidTimeRange()) {
                alert('No se puede enviar: la hora "Disponible Hasta" debe ser posterior a "Disponible Desde".');
                e.preventDefault();
            }
        });
    });
</script>

@endsection
