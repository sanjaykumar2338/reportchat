<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4" style="width: 92%; margin-left: 176px;">
    <h2>Todos los Reportes</h2>

    <!-- Formulario de Búsqueda y Filtro -->
    <form action="<?php echo e(route('admin.chats')); ?>" method="GET" class="mb-3">
        <div class="row">
            <!-- Campo de Búsqueda -->
            <div class="col-md-4">
                <input type="text" name="search" class="form-control" placeholder="Buscar por título..." value="<?php echo e(request('search')); ?>">
            </div>

            <!-- Lista Desplegable de Estado -->
            <div class="col-md-3">
                <select name="status" class="form-control">
                    <option value="">Filtrar por Estado</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pendiente</option>
                    <option value="solved" <?php echo e(request('status') == 'solved' ? 'selected' : ''); ?>>Resuelto</option>
                    <option value="refused" <?php echo e(request('status') == 'refused' ? 'selected' : ''); ?>>Rechazado</option>
                </select>
            </div>

            <!-- Botón de Búsqueda -->
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Buscar</button>
            </div>

            <!-- Botón de Restablecer -->
            <div class="col-md-2">
                <a href="<?php echo e(route('admin.chats')); ?>" class="btn btn-secondary w-100">Restablecer</a>
            </div>
        </div>
    </form>

    <!-- Tabla de Reportes -->
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Ubicación</th>
                <th>Estado</th>
                <th>Creado el</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if($chats->count() > 0): ?>
                <?php $__currentLoopData = $chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($chat->id); ?></td>
                        <td><?php echo e($chat->title); ?></td>
                        <td><?php echo e($chat->location); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($chat->status == 'solved' ? 'success' : 
                                ($chat->status == 'pending' ? 'warning' : 
                                ($chat->status == 'refused' ? 'danger' : 'secondary'))); ?>" id="status-badge-<?php echo e($chat->id); ?>">
                                <?php echo e(ucfirst($chat->status == 'pending' ? 'pendiente' : ($chat->status == 'solved' ? 'resuelto' : ($chat->status == 'refused' ? 'rechazado' : $chat->status)))); ?>

                            </span>
                        </td>
                        <td><?php echo e($chat->created_at->format('d M Y, h:i A')); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.view.chat', $chat->id)); ?>" class="btn btn-sm btn-primary">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted">
                        <strong>No se encontraron resultados.</strong>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <?php echo e($chats->links('vendor.pagination.bootstrap-5')); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/chats/index.blade.php ENDPATH**/ ?>