<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4" style="margin-left: 176px; width: 92%;">
    <?php $editing = isset($category); ?>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2><?php echo e($editing ? 'Editar Categoría' : 'Crear Categoría'); ?></h2>
        <a href="<?php echo e(route('admin.marketplace_categories.index')); ?>" class="btn btn-secondary">Volver</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e($editing
        ? route('admin.marketplace_categories.update', $category->id)
        : route('admin.marketplace_categories.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="name" class="form-control"
                   value="<?php echo e(old('name', $category->name ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Icono (archivo o texto)</label>
            <input type="text" name="icon" class="form-control"
                   value="<?php echo e(old('icon', $category->icon ?? '')); ?>" placeholder="ej: product-icon.png">
            <small class="text-muted">Puedes guardar solo el nombre del icono o la ruta si ya existe.</small>
        </div>

        <button class="btn btn-primary"><?php echo e($editing ? 'Actualizar' : 'Crear'); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/marketplace_categories/form.blade.php ENDPATH**/ ?>