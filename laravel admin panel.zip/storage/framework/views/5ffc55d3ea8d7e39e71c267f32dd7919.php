<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
  <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left:176px; width:92%;">
    <h2>Anuncios del Mercado</h2>
    <a href="<?php echo e(route('admin.marketplace.create')); ?>" class="btn btn-success">+ Crear Anuncio</a>
  </div>

  <form method="GET" action="<?php echo e(route('admin.marketplace.index')); ?>" style="width:92%; margin-left:176px;" class="mb-3">
    <div class="row">
      <div class="col-md-3">
        <input type="text" name="q" class="form-control" placeholder="Buscar título/desc/WhatsApp" value="<?php echo e(request('q')); ?>">
      </div>
      <div class="col-md-3">
        <select name="category_id" class="form-control">
          <option value="">-- Categoría --</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if(request('category_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-3">
        <select name="user_id" class="form-control">
          <option value="">-- Usuario --</option>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php if(request('user_id')==$u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?> (<?php echo e($u->username); ?>)</option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-2">
        <select name="active" class="form-control">
          <option value="">-- Activo? --</option>
          <option value="1" <?php if(request('active')==='1'): echo 'selected'; endif; ?>>Sí</option>
          <option value="0" <?php if(request('active')==='0'): echo 'selected'; endif; ?>>No</option>
        </select>
      </div>
      <div class="col-md-1 d-grid">
        <button class="btn btn-primary">Buscar</button>
      </div>
    </div>
  </form>

  <table class="table table-bordered" style="width:92%; margin-left:176px;">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Categoría</th>
        <th>Precio</th>
        <th>Usuario</th>
        <th>Activo</th>
        <th>Publicado</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($l->id); ?></td>
          <td><?php echo e($l->title); ?></td>
          <td><?php echo e($l->category->name ?? '-'); ?></td>
          <td>$<?php echo e(number_format($l->price ?? 0, 2)); ?></td>
          <td><?php echo e($l->user->name ?? '-'); ?></td>
          <td><span class="badge bg-<?php echo e($l->is_active ? 'success' : 'secondary'); ?>"><?php echo e($l->is_active ? 'Sí' : 'No'); ?></span></td>
          <td><?php echo e(optional($l->published_at)->format('Y-m-d H:i')); ?></td>
          <td>
            <a href="<?php echo e(route('admin.marketplace.edit', $l->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
            <form method="POST" action="<?php echo e(route('admin.marketplace.destroy', $l->id)); ?>" style="display:inline;" onsubmit="return confirm('¿Eliminar anuncio?')">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn btn-sm btn-danger">Eliminar</button>
            </form>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="8" class="text-center text-muted"><strong>No se encontraron anuncios.</strong></td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <div class="mt-3" style="margin-left:176px;">
    <?php echo e($listings->links('vendor.pagination.bootstrap-5')); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/marketplace/index.blade.php ENDPATH**/ ?>