<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2>Gestión de Reservas</h2>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2>&nbsp;</h2>
        <div>
            <a href="<?php echo e(route('admin.reservations.calendar')); ?>" class="btn btn-outline-primary me-2">📅 Vista de Calendario</a>
        </div>
    </div>

    <!-- Formulario de Búsqueda -->
    <form method="GET" action="<?php echo e(route('admin.reservations.index')); ?>" style="width: 92%; margin-left: 176px;" class="mb-3">
        <div class="row">
            <div class="col-md-3">
                <input type="date" name="date" class="form-control" value="<?php echo e(request('date')); ?>">
            </div>
            <div class="col-md-3">
                <select name="room_id" class="form-control">
                    <option value="">Todas las Salas</option>
                    <?php $__currentLoopData = \App\Models\Room::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>" <?php echo e(request('room_id') == $room->id ? 'selected' : ''); ?>>
                            <?php echo e($room->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <input type="text" name="user_id" class="form-control" placeholder="ID de Usuario" value="<?php echo e(request('user_id')); ?>">
            </div>
            <div class="col-md-3 d-flex">
                <button type="submit" class="btn btn-primary me-2">Buscar</button>
                <a href="<?php echo e(route('admin.reservations.index')); ?>" class="btn btn-secondary">Restablecer</a>
            </div>
        </div>
    </form>

    <table class="table table-bordered" style="width: 92%; margin-left: 176px;">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Sala</th>
                <th>Usuario</th>
                <th>Fecha</th>
                <th>Hora de Inicio</th>
                <th>Hora de Fin</th>
                <th>Duración (min)</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($reservation->id); ?></td>
                    <td><?php echo e($reservation->room->name ?? 'N/A'); ?></td>
                    <td><?php echo e($reservation->user->name ?? $reservation->user_id); ?></td>
                    <td><?php echo e($reservation->date); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($reservation->start_time)->format('g:i A')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($reservation->end_time)->format('g:i A')); ?></td>
                    <td><?php echo e($reservation->duration_minutes); ?></td>
                    <td>
                        <?php if($reservation->status == 1): ?>
                            <span class="badge bg-danger">Cancelada</span>
                        <?php else: ?>
                            <span class="badge bg-success">Reservada</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.reservations.edit', $reservation->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.reservations.destroy', $reservation->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('¿Estás seguro?')" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted"><strong>No se encontraron reservas.</strong></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-3" style="margin-left: 176px;">
        <?php echo e($reservations->links('vendor.pagination.bootstrap-5')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/reservations/index.blade.php ENDPATH**/ ?>