<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $editing = isset($listing); ?>

<div class="container mt-4" style="margin-left:176px; width:92%;">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2><?php echo e($editing ? 'Editar Anuncio' : 'Crear Anuncio'); ?></h2>
    <a href="<?php echo e(route('admin.marketplace.index')); ?>" class="btn btn-secondary">Volver</a>
  </div>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    </div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data"
        action="<?php echo e($editing ? route('admin.marketplace.update',$listing->id) : route('admin.marketplace.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($editing): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Usuario</label>
        <select name="user_id" class="form-control" required>
          <option value="">-- Seleccione --</option>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php if(old('user_id', $listing->user_id ?? '')==$u->id): echo 'selected'; endif; ?>><?php echo e($u->name); ?> (<?php echo e($u->username); ?>)</option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div class="col-md-6 mb-3">
        <label class="form-label">Categoría</label>
        <select name="category_id" class="form-control" required>
          <option value="">-- Seleccione --</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if(old('category_id', $listing->category_id ?? '')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Título</label>
      <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $listing->title ?? '')); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Descripción</label>
      <textarea name="description" class="form-control" rows="4"><?php echo e(old('description', $listing->description ?? '')); ?></textarea>
    </div>

    <div class="row">
      <div class="col-md-4 mb-3">
        <label class="form-label">Precio</label>
        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $listing->price ?? '')); ?>">
      </div>
      <div class="col-md-4 mb-3">
        <label class="form-label">WhatsApp</label>
        <input type="text" name="whatsapp" class="form-control" value="<?php echo e(old('whatsapp', $listing->whatsapp ?? '')); ?>" required>
      </div>
      <div class="col-md-4 mb-3">
        <div class="form-check mt-4">
          <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active"
            <?php echo e(old('is_active', $listing->is_active ?? true) ? 'checked' : ''); ?>>
          <label class="form-check-label" for="is_active">Activo</label>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6 mb-3">
        <label class="form-label">Publicado en</label>
        <input type="datetime-local" name="published_at" class="form-control"
               value="<?php echo e(old('published_at', optional($listing->published_at ?? null)->format('Y-m-d\TH:i'))); ?>">
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Finaliza en</label>
        <input type="datetime-local" name="ends_at" class="form-control"
               value="<?php echo e(old('ends_at', optional($listing->ends_at ?? null)->format('Y-m-d\TH:i'))); ?>">
      </div>
    </div>

    <div class="mb-3">
      <label class="form-label">Imágenes (múltiples)</label>
      <input type="file" name="images[]" class="form-control" multiple>
      <small class="text-muted">Se permiten múltiples imágenes (máx. 4MB cada una).</small>
    </div>

    <?php if(!empty($listing?->images)): ?>
      <div class="mb-3">
        <label class="form-label">Imágenes actuales</label>
        <div class="d-flex flex-wrap gap-3">
          <?php $__currentLoopData = $listing->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="border p-2 text-center">
              <img src="<?php echo e(asset('storage/'.$img)); ?>" alt="" style="height:80px; display:block; margin-bottom:8px;">
              <div class="form-check">
                <input class="form-check-input" name="remove_images[]" type="checkbox" value="<?php echo e($img); ?>" id="rm_<?php echo e(md5($img)); ?>">
                <label class="form-check-label" for="rm_<?php echo e(md5($img)); ?>">Quitar</label>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endif; ?>

    <button class="btn btn-primary"><?php echo e($editing ? 'Actualizar' : 'Crear'); ?></button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/marketplace/form.blade.php ENDPATH**/ ?>