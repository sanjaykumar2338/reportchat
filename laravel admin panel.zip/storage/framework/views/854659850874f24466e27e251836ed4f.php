<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4" style="width: 92%; margin-left: 176px;">
    <h2>Detalles del Usuario</h2>
    <div class="card p-4">
        <h4>Nombre: <?php echo e($user->name); ?></h4>
        <p><strong>Correo:</strong> <?php echo e($user->email); ?></p>
        <p><strong>Teléfono:</strong> <?php echo e($user->phone); ?></p>
        <?php if($user->companyRelation?->name): ?>
            <p><strong>Empresa:</strong> <?php echo e($user->companyRelation->name ?? '-'); ?></p>
        <?php endif; ?>
        <p><strong>Creado el:</strong> <?php echo e($user->created_at->format('d M Y, h:i A')); ?></p>

        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary mt-3">Volver</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/users/show.blade.php ENDPATH**/ ?>