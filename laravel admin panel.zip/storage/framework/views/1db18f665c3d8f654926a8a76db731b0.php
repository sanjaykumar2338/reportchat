<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2><?php echo e(isset($room) ? 'Editar Sala' : 'Agregar Sala'); ?></h2>
        <a href="<?php echo e(route('admin.rooms.index')); ?>" class="btn btn-secondary">Volver</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="margin-left: 176px; width: 92%;">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(isset($room) ? route('admin.rooms.update', $room->id) : route('admin.rooms.store')); ?>" method="POST" enctype="multipart/form-data" style="margin-left: 176px; width: 92%;">
        <?php echo csrf_field(); ?>
        <?php if(isset($room)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $room->name ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Piso</label>
            <input type="text" name="floor" class="form-control" value="<?php echo e(old('floor', $room->floor ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <select name="category" class="form-control" required>
                <option value="">Seleccionar Categoría</option>
                <option value="Sala" <?php echo e(old('category', $room->category ?? '') == 'Sala' ? 'selected' : ''); ?>>Sala</option>
                <option value="Auditorio" <?php echo e(old('category', $room->category ?? '') == 'Auditorio' ? 'selected' : ''); ?>>Auditorio</option>
                <option value="Roof" <?php echo e(old('category', $room->category ?? '') == 'Roof' ? 'selected' : ''); ?>>Roof</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="company">Empresa</label>
            <select name="company" id="company" class="form-control">
                <option value="">Seleccionar una empresa</option>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($company->id); ?>"
                        <?php echo e(old('company', isset($room) ? $room->company : '') == $company->id ? 'selected' : ''); ?>>
                        <?php echo e($company->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3 row">
            <div class="col">
                <label class="form-label">Disponible Desde</label>
                <input type="time" name="available_from" class="form-control" value="<?php echo e(old('available_from', $room->available_from ?? '')); ?>" required>
            </div>
            <div class="col">
                <label class="form-label">Disponible Hasta</label>
                <input type="time" name="available_to" class="form-control" value="<?php echo e(old('available_to', $room->available_to ?? '')); ?>" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Capacidad</label>
            <input type="number" name="capacity" class="form-control" value="<?php echo e(old('capacity', $room->capacity ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Imagen</label>
            <input type="file" name="image" class="form-control">
            <?php if(isset($room) && $room->image_url): ?>
                <div class="mt-2">
                    <img src="<?php echo e(url($room->image_url)); ?>" alt="Imagen de la Sala" width="120">
                    <div class="form-check mt-2">
                        <input type="checkbox" name="remove_image" class="form-check-input" id="remove_image">
                        <label class="form-check-label" for="remove_image">Eliminar imagen existente</label>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($room) ? 'Actualizar Sala' : 'Crear Sala'); ?></button>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const timeInputs = document.querySelectorAll('input[type="time"]');
        const fromInput = document.querySelector('input[name="available_from"]');
        const toInput = document.querySelector('input[name="available_to"]');
        const form = document.querySelector('form');

        function roundTime(input) {
            if (!input.value) return;
            let [hour, minute] = input.value.split(':');
            minute = parseInt(minute);
            if (minute !== 0 && minute !== 30) {
                let rounded = minute < 30 ? '00' : '30';
                input.value = `${hour.padStart(2, '0')}:${rounded}`;
            }
        }

        function isValidTimeRange() {
            if (fromInput.value && toInput.value) {
                const [fromHour, fromMin] = fromInput.value.split(':').map(Number);
                const [toHour, toMin] = toInput.value.split(':').map(Number);

                const fromMinutes = fromHour * 60 + fromMin;
                const toMinutes = toHour * 60 + toMin;

                return toMinutes > fromMinutes;
            }
            return true;
        }

        function validateTimeOrder() {
            if (!isValidTimeRange()) {
                alert('La hora de finalización debe ser después de la hora de inicio.');
                toInput.value = '';
            }
        }

        roundTime(fromInput);
        roundTime(toInput);

        timeInputs.forEach(input => {
            input.addEventListener('change', function () {
                roundTime(this);
                validateTimeOrder();
            });
            input.addEventListener('keydown', e => e.preventDefault());
        });

        form.addEventListener('submit', function (e) {
            roundTime(fromInput);
            roundTime(toInput);
            if (!isValidTimeRange()) {
                alert('No se puede enviar: la hora "Disponible Hasta" debe ser posterior a "Disponible Desde".');
                e.preventDefault();
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/rooms/add.blade.php ENDPATH**/ ?>