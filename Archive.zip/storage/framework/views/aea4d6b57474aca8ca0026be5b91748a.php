<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2>Gestión de Categorías (Marketplace)</h2>
        <a href="<?php echo e(route('admin.marketplace_categories.create')); ?>" class="btn btn-success">+ Crear Categoría</a>
    </div>

    <form method="GET" action="<?php echo e(route('admin.marketplace_categories.index')); ?>" style="width: 92%; margin-left: 176px;" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="name" class="form-control" placeholder="Buscar por Nombre" value="<?php echo e(request('name')); ?>">
            </div>
            <div class="col-md-4">
                <input type="text" name="icon" class="form-control" placeholder="Buscar por Icono" value="<?php echo e(request('icon')); ?>">
            </div>
            <div class="col-md-4 d-flex">
                <button type="submit" class="btn btn-primary me-2">Buscar</button>
                <a href="<?php echo e(route('admin.marketplace_categories.index')); ?>" class="btn btn-secondary">Restablecer</a>
            </div>
        </div>
    </form>

    <table class="table table-bordered" style="width: 92%; margin-left: 176px;">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Icono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($c->id); ?></td>
                    <td><?php echo e($c->name); ?></td>
                    <td><?php echo e($c->icon); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.marketplace_categories.edit', $c->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.marketplace_categories.destroy', $c->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('¿Estás seguro?')" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center text-muted"><strong>No se encontraron categorías.</strong></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-3" style="margin-left: 176px;">
        <?php echo e($categories->links('vendor.pagination.bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/marketplace_categories/index.blade.php ENDPATH**/ ?>