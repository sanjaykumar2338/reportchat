<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2>Gestión de Salas</h2>
        <a href="<?php echo e(route('admin.rooms.create')); ?>" class="btn btn-success">+ Agregar Sala</a>
    </div>

    <!-- Formulario de Búsqueda -->
    <form method="GET" action="<?php echo e(route('admin.rooms.index')); ?>" style="width: 92%; margin-left: 176px;" class="mb-3">
        <div class="row">
            <div class="col-md-3">
                <input type="text" name="name" class="form-control" placeholder="Buscar por Nombre de Sala" value="<?php echo e(request('name')); ?>">
            </div>
            <div class="col-md-3">
                <select name="category" class="form-control">
                    <option value="">Todas las Categorías</option>
                    <option value="Sala" <?php echo e(request('category') == 'Sala' ? 'selected' : ''); ?>>Sala</option>
                    <option value="Auditorio" <?php echo e(request('category') == 'Auditorio' ? 'selected' : ''); ?>>Auditorio</option>
                    <option value="Roof" <?php echo e(request('category') == 'Roof' ? 'selected' : ''); ?>>Roof</option>
                </select>
            </div>
            <div class="col-md-6 d-flex">
                <button type="submit" class="btn btn-primary me-2">Buscar</button>
                <a href="<?php echo e(route('admin.rooms.index')); ?>" class="btn btn-secondary">Restablecer</a>
            </div>
        </div>
    </form>

    <table class="table table-bordered" style="width: 92%; margin-left: 176px;">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Piso</th>
                <th>Categoría</th>
                <th>Capacidad</th>
                <th>Disponibilidad</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($room->id); ?></td>
                    <td><?php echo e($room->name); ?></td>
                    <td><?php echo e($room->floor); ?></td>
                    <td><?php echo e($room->category); ?></td>
                    <td><?php echo e($room->capacity); ?></td>
                    <td>
                        <?php echo e(\Carbon\Carbon::parse($room->available_from)->format('g:i A')); ?>

                        -
                        <?php echo e(\Carbon\Carbon::parse($room->available_to)->format('g:i A')); ?>

                    </td>
                    <td>
                        <?php if($room->image_url): ?>
                            <a href="<?php echo e(url($room->image_url)); ?>" target="_blank">
                                <img src="<?php echo e(url($room->image_url)); ?>" alt="Imagen de la Sala" width="60">
                            </a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>           
                    <td>
                        <a href="<?php echo e(route('admin.rooms.edit', $room->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.rooms.destroy', $room->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('¿Estás seguro?')" class="btn btn-sm btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted"><strong>No se encontraron salas.</strong></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <div class="mt-3" style="margin-left: 176px;">
        <?php echo e($rooms->links('vendor.pagination.bootstrap-5')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/rooms/index.blade.php ENDPATH**/ ?>