<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <h2 style="margin-left: 176px;">Gestión de Empresas</h2>

    <!-- Formulario de Búsqueda -->
    <form method="GET" action="<?php echo e(route('admin.companies.index')); ?>" style="width: 92%; margin-left: 176px;" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="name" class="form-control" placeholder="Buscar por Nombre de Empresa" value="<?php echo e(request('name')); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">Buscar</button>
                <a href="<?php echo e(route('admin.companies.index')); ?>" class="btn btn-secondary">Restablecer</a>
            </div>
            <div class="col-md-4 text-end">
                <a href="<?php echo e(route('admin.companies.create')); ?>" class="btn btn-success">Agregar Empresa</a>
            </div>
        </div>
    </form>

    <!-- Botón de Notificación -->
    <div class="text-end mb-3" style="width: 92%; margin-left: 176px;">
        <button type="button" id="openNotificationModal" class="btn btn-primary" disabled>Enviar Notificación</button>
    </div>

    <table class="table table-bordered" style="width: 92%; margin-left: 176px;">
        <thead class="table-dark">
            <tr>
                <th><input type="checkbox" id="selectAllCompanies"></th>
                <th>ID</th>
                <th>Nombre de la Empresa</th>
                <th>Creada el</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if($companies->count() > 0): ?>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" class="company-checkbox" value="<?php echo e($company->id); ?>"></td>
                    <td><?php echo e($company->id); ?></td>
                    <td><?php echo e($company->name); ?></td>
                    <td><?php echo e($company->created_at->format('d M Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.companies.edit', $company->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.companies.destroy', $company->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">
                        <strong>No se encontraron empresas.</strong>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Paginación -->
    <?php echo e($companies->links('vendor.pagination.bootstrap-5')); ?>

</div>

<!-- Modal de Notificación -->
<div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content p-4 shadow-sm">
      <div class="modal-header border-bottom">
        <h5 class="modal-title fw-bold">Enviar Notificación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="sendNotificationForm">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="companies" id="selectedCompanies">
          <div class="mb-3">
            <label>Título de la Notificación</label>
            <input type="text" class="form-control" name="title" required />
          </div>
          <div class="mb-3">
            <label>Mensaje</label>
            <textarea class="form-control" name="message" rows="4" required></textarea>
          </div>
          <button type="submit" class="btn btn-success">Enviar</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const openModalBtn = document.getElementById('openNotificationModal');
    const checkboxes = document.querySelectorAll('.company-checkbox');
    const selectedCompaniesField = document.getElementById('selectedCompanies');

    checkboxes.forEach(chk => {
        chk.addEventListener('change', () => {
            const selected = Array.from(checkboxes).filter(c => c.checked);
            openModalBtn.disabled = selected.length === 0;
        });
    });

    openModalBtn.addEventListener('click', () => {
        const selected = Array.from(checkboxes)
            .filter(c => c.checked)
            .map(c => c.value);
        selectedCompaniesField.value = selected.join(',');
        const modal = new bootstrap.Modal(document.getElementById('notificationModal'));
        modal.show();
    });

    document.getElementById('sendNotificationForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        fetch('<?php echo e(url("/admin/companies/send-notification")); ?>', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message || '¡Notificación enviada!');
        })
        .catch(err => {
            alert('Error al enviar la notificación');
        });
    });

    document.getElementById('selectAllCompanies').addEventListener('change', function () {
        checkboxes.forEach(c => c.checked = this.checked);
        openModalBtn.disabled = !this.checked;
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/companies/index.blade.php ENDPATH**/ ?>