<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3" style="margin-left: 176px; width: 92%;">
        <h2><?php echo e(isset($reservation) ? 'Editar Reserva' : 'Crear Reserva'); ?></h2>
        <a href="<?php echo e(route('admin.reservations.index')); ?>" class="btn btn-secondary">Volver</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="margin-left: 176px; width: 92%;">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(isset($reservation) ? route('admin.reservations.update', $reservation->id) : route('admin.reservations.store')); ?>" method="POST" style="margin-left: 176px; width: 92%;">
        <?php echo csrf_field(); ?>
        <?php if(isset($reservation)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="mb-3">
            <label class="form-label">Sala</label>
            <select name="room_id" class="form-control" required>
                <option value="">Seleccionar Sala</option>
                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($room->id); ?>" <?php echo e((old('room_id', $reservation->room_id ?? '') == $room->id) ? 'selected' : ''); ?>>
                        <?php echo e($room->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Usuario</label>
            <select name="user_id" class="form-control" required>
                <option value="">Seleccionar Usuario</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e((old('user_id', $reservation->user_id ?? '') == $user->id) ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Fecha</label>
            <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $reservation->date ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Hora de Inicio</label>
            <input type="time" name="start_time" class="form-control" value="<?php echo e(old('start_time', $reservation->start_time ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Hora de Fin</label>
            <input type="time" name="end_time" class="form-control" value="<?php echo e(old('end_time', $reservation->end_time ?? '')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Duración</label>
            <input type="number" name="duration_minutes" class="form-control" value="<?php echo e(old('duration_minutes', $reservation->duration_minutes ?? '')); ?>" min="1" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Estado</label>
            <select name="status" class="form-control" required>
                <option value="0" <?php echo e(old('status', $reservation->status ?? '') == 0 ? 'selected' : ''); ?>>Reservada</option>
                <option value="1" <?php echo e(old('status', $reservation->status ?? '') == 1 ? 'selected' : ''); ?>>Cancelada</option>
            </select>
        </div>

        <div class="mb-3">
            <button type="submit" class="btn btn-primary"><?php echo e(isset($reservation) ? 'Actualizar' : 'Crear'); ?></button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/myworkplace/dainel waiser/reportchat/resources/views/admin/reservations/edit.blade.php ENDPATH**/ ?>